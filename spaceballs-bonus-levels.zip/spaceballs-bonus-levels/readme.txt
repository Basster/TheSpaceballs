*****************************************
*					*
*     THE SPACEBALLS - Bonus Levels	*
*					*
*****************************************
*					*
* To load these bonus levels just start	*
*   the Spaceballs game and click the	*
*  button 'Load Levels' and upload one	*
*            of the files...		*
*					*
*       Have fun on your mission!	*
*					*
*****************************************
*					*
*      http://www.thespaceballs.de	*
*					*
*****************************************